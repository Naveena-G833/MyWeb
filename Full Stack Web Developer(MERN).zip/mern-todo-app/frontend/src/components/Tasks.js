import React, { useEffect, useState } from 'react';
import API from '../api';
import AddTask from './AddTask';
import TaskItem from './TaskItem';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const res = await API.get('/tasks');
      setTasks(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchTasks(); }, []);

  const addTask = (task) => setTasks((t) => [task, ...t]);
  const updateTask = (updated) => setTasks((t) => t.map(x => x._id === updated._id ? updated : x));
  const deleteTask = (id) => setTasks((t) => t.filter(x => x._id !== id));

  const logout = () => { localStorage.removeItem('token'); window.location.reload(); };

  return (
    <div className="card">
      <div className="header"><h2>Your Tasks</h2><button onClick={logout}>Logout</button></div>
      <AddTask onAdd={addTask} />
      <div>
        {tasks.map(task => (
          <TaskItem key={task._id} task={task} onUpdate={updateTask} onDelete={deleteTask} />
        ))}
      </div>
    </div>
  );
}