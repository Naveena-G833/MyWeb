import React, { useState } from 'react';
import API from '../api';

export default function AddTask({ onAdd }) {
  const [content, setContent] = useState('');
  const submit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    try {
      const res = await API.post('/tasks', { content });
      onAdd(res.data);
      setContent('');
    } catch (err) { console.error(err); }
  };
  return (
    <form onSubmit={submit} className="addtask">
      <input value={content} onChange={(e) => setContent(e.target.value)} placeholder="Add a new task" />
      <button type="submit">Add</button>
    </form>
  );
}