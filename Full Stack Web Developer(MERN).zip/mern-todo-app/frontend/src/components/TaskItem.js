import React, { useState } from 'react';
import API from '../api';

export default function TaskItem({ task, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(task.content);

  const toggleComplete = async () => {
    try {
      const res = await API.put(`/tasks/${task._id}`, { completed: !task.completed });
      onUpdate(res.data);
    } catch (err) { console.error(err); }
  };

  const save = async () => {
    try {
      const res = await API.put(`/tasks/${task._id}`, { content: text });
      onUpdate(res.data);
      setEditing(false);
    } catch (err) { console.error(err); }
  };

  const remove = async () => {
    try {
      await API.delete(`/tasks/${task._id}`);
      onDelete(task._id);
    } catch (err) { console.error(err); }
  };

  return (
    <div className={`task-item ${task.completed ? 'completed' : ''}`}>
      <input type="checkbox" checked={task.completed} onChange={toggleComplete} />
      {editing ? (
        <>
          <input value={text} onChange={(e) => setText(e.target.value)} />
          <button onClick={save}>Save</button>
          <button onClick={() => { setEditing(false); setText(task.content); }}>Cancel</button>
        </>
      ) : (
        <>
          <span>{task.content}</span>
          <div className="actions">
            <button onClick={() => setEditing(true)}>Edit</button>
            <button onClick={remove}>Delete</button>
          </div>
        </>
      )}
    </div>
  );
}